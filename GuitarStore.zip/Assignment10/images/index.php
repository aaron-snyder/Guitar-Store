<?php
header("Location: ../../index.php");
exit(); // Ensure that no further code is executed after the redirection
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Under Construction</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <!--UNDER CONSTRUCTION-->
    </body>
</html>

$(document).ready(function(){
    $('.bxslider').bxSlider({
      auto: true,
      slideWidth: 500,
      controls: false,
      pagerType: 'short',
      captions: true,
      randomStart: true,
      speed: 3000
    });
  });
<nav>
    <ul>
        <li><a href="index.php?action=home">Home</a></li>
        <li><a href="index.php?action=lessons">Lessons</a></li>
        <li><a href="index.php?action=products">Products</a></li>
        <li><a href="index.php?action=support">Support</a></li>
        <li><a href="index.php?action=shipping">Shipping</a></li>
        <li><a href="index.php?action=contact_us">Contact Us</a>
            <ul>
                <li><a href="index.php?action=email">Email</a></li>
                <li><a href="index.php?action=phone">Phone</a></li>
                <li><a href="index.php?action=live_chat">Live Chat</a></li>
            </ul>
        </li>
    </ul>
</nav>
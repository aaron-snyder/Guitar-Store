<footer id="footer">
    <p>&copy;2024 The Guitar Store <span id="formattedDate"></span></p>
</footer>